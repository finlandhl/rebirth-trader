# Trading Session — 2026-07-13

**Session span:** 2026-07-12 21:01 UTC → 2026-07-13 22:06 UTC  
**Duration:** 25h 4min  
**Restarts this session:** 11

---

## Summary

| Metric | Value |
|:-------|:------|
| **Initial Capital** | $10.31 |
| **Available Capital** | $10.12 |
| **Realized PnL (pnl_usd)** | **$4.22** |
| **Realized PnL (bot calc)** | **$3.66** |
| **Unrealized PnL (open positions)** | $0.18 |
| **Total positions created** | 112 |
| **Closed trades** | 95 |
| **Active positions** | 17 |
| **Win rate** | 49.5% (47 wins / 48 losses) |

---

## Exit Reason Breakdown

| Exit Type | Count |
|:----------|:------|
| Time Limit | 33 |
| Stop Loss | 20 |
| Loss Trail | 13 |
| Trailing Stop | 11 |
| By Supervisor | 10 |
| Profit Target | 4 |

---

## Top & Bottom Trades

| | Symbol | PnL | Reason |
|:--|:-------|:----|:-------|
| 🏆 **Best** | 1000XECUSDT | **+$3.09** | By Supervisor |
| 💀 **Worst** | AIOUSDT | **-$0.53** | Stop Loss: -3.20% |

---

## Best & Worst Performers (by cumulative ranking)

| | Symbol | Cumulative PnL (ratio) |
|:--|:-------|:----------------------|
| 🟢 **Best** | 1000XECUSDT | +3.24 |
| 🔴 **Worst** | AIOUSDT | -0.53 |

---

## Active Positions (17)

```
1000BONKUSDT  AIGENSYNUSDT  AIOUSDT       ARBUSDT       ARXUSDT
AVAXUSDC      AVAXUSDT      BNBUSDC       CELRUSDT      FARTCOINUSDT
FOLKSUSDT     KAITOUSDT     MAGMAUSDT     OGNUSDT       1000PEPEUSDC
1000PEPEUSDT  1000SHIBUSDT
```

---

*Generated from state.jsonl snapshot at 2026-07-13T22:06:31 UTC*
